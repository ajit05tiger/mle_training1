from setuptools import setup

setup(
    name="py_packages",
    version="0.1",
    description="This is code for predicting house price",
    author="ajit05tiger",
    install_requires=[],
)
